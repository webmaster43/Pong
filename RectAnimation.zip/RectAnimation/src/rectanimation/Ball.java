/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectanimation;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

/**
 *
 * @author Tutor 101
 */
public class Ball {

    public int width = 30;
    public int height = 30;
    public int motionX;
    public int motionY;
    public int x, y;
    private RectAnimation pong;
    public Random random;

    public int amountOfHits;

    public Ball(RectAnimation pong) {
        this.random = new Random();
        this.pong = pong;
        spawn();
    }

    public void update(paddle paddle1, paddle paddle2) {

        int speed = 5;

        this.x += motionX * speed;
        this.y += motionY * speed;
        if (this.y + height > pong.height || this.y < 0) {
            if (this.motionY < 0) {
                this.y = 0;
                this.motionY = random.nextInt(4);
                if (motionY == 0) {
                    motionY = 1;
                }
            } else {
                this.y = pong.height - height - motionY;
                this.motionY = -random.nextInt(4);
                if (motionY == 0) {
                    motionY = -1;
                }

            }
        }
        if (checkCollision(paddle1) == 1) {
            this.motionX = 1 + (amountOfHits / 5);
            this.motionY = -2 + random.nextInt(4);
            if (motionY == 0) {
                motionY = 1;
            }
            amountOfHits++;
        } else if (checkCollision(paddle2) == 1) {
            this.motionX = -1 - (amountOfHits / 5);
            this.motionY = -2 + random.nextInt(4);
            if (motionY == 0) {
                motionY = -1;
            }
        }

        if (checkCollision(paddle1) == 2) {
            paddle2.score++;
            spawn();
        } else if (checkCollision(paddle2) == 2) {
            paddle1.score++;
            spawn();
        }
    }

    public void spawn() {
        this.amountOfHits = 0;
        this.x = pong.width / 2 - this.width / 2;
        this.y = pong.height / 2 - this.height / 2;
        this.motionX = -1 + random.nextInt(4);

        if (motionY == 0) {
            motionY = 1;
        }
        if (random.nextBoolean()) {
            motionX = 1;
        } else {
            motionX = -1;
        }

    }

    public int checkCollision(paddle pad) {

        if (this.x < pad.x + pad.width && this.x + width > pad.x && this.y < pad.y + pad.height && this.y + height > pad.y) {
            return 1; //bounce
        } else if (pad.x > x + width && pad.paddleNumber == 1 || pad.x < x && pad.paddleNumber == 2) {
            return 2; //score
        }

        return 0;

    }

    public void render(Graphics g) {

        g.setColor(Color.WHITE);
        g.fillOval(x, y, width, height);

    }

}
