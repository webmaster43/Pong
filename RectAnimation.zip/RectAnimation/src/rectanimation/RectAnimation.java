/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectanimation;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 *
 * @author Tutor 101
 */
public class RectAnimation implements ActionListener, KeyListener {

    public static RectAnimation rectAnimation;
    public gamePong renderer;

    public paddle player1;
    public paddle player2;

    public Ball ball;
    public int width = 700, height = 700;

    public boolean bot = false;
    public boolean w = false;
    public boolean s = false;
    public boolean up = false;
    public boolean down = false;
    public int gameStatus = 0;
    public int botMoves;
    public int botCoolDown = 0;
    public int botDifficulty = 0;
    public RectAnimation() {

        Timer timer = new Timer(20, this);

        JFrame frame = new JFrame("Rectangle Animation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setVisible(true);
        frame.setResizable(true);
        frame.setSize(width + 15, height + 30);
        frame.setLocation(375, 55);

        renderer = new gamePong();
        frame.add(renderer);

        frame.addKeyListener(this);

        timer.start();
    }

//    @Override
//    public void paintComponent(Graphics g) {
//        super.paintComponent(g);
//
//        g.setColor(Color.RED);
//        g.fillRect( x ,y, 50, 30);
//        
//        tm.start();
//    }
    public void render(Graphics2D g) {

        g.setColor(Color.BLACK);
        g.fillRect(0, 0, width, height);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (gameStatus == 0) {
            g.setColor(Color.WHITE);
            g.setFont(new Font("Ariel", 1, 50));
            g.drawString("PONG", width / 2 - 70, 50);

            g.setFont(new Font("Ariel", 1, 20));
            g.drawString("Press Space to Play", width / 2 - 90, height / 2 + 50);
        }

        if (gameStatus == 1 || gameStatus == 2) {
            g.setColor(Color.WHITE);
            g.setStroke(new BasicStroke(10));
            g.drawLine(width / 2, 0, width / 2, height);
            g.drawOval(width / 2 - 100, height / 2 - 100, 200, 200);
            g.setFont(new Font("Ariel", 1, 50));
            g.drawString(String.valueOf(player1.score), width / 2 - 70, 50);

            g.setFont(new Font("Ariel", 1, 50));
            g.drawString(String.valueOf(player2.score), width / 2 + 65, 50);

            player1.render(g);
            player2.render(g);
            ball.render(g);
        }
        if (gameStatus == 1) {
            g.setColor(Color.WHITE);
            g.setFont(new Font("Ariel", 1, 50));
            g.drawString("PAUSED", width / 2 - 100, 50);
        }

    }

    public void start() {
        player1 = new paddle(this, 1);
        player2 = new paddle(this, 2);
        ball = new Ball(this);
        gameStatus = 2;
    }

    public void update() {

        if (w) {
            player1.move(true);
        } else if (s) {
            player1.move(false);
        } else if (!bot) {
            if (up) {
                player2.move(true);
            }
            if (down) {
                player2.move(false);
            }
        } else {

            if (botCoolDown > 0) {
                botCoolDown--;
                if (botCoolDown == 0) {
                    botMoves = 0;
                }
            }

            if (botMoves < 10) {
                
                if (player2.y + player2.height < ball.y) {
                    player2.move(false);
                    botMoves++;
                }
                if (player2.y  + player2.height  > ball.y) {
                    player2.move(true);
                    botMoves++;
                }
                if(botDifficulty == 0)
                    botCoolDown = 30;
                else if(botDifficulty == 1)
                    botCoolDown = 20;
                else if(botDifficulty == 2)
                    botCoolDown = 10;
            }
        }
        ball.update(player1, player2);
    }

    public void actionPerformed(ActionEvent e) {
        if (gameStatus == 2) {
            update();
        }
        renderer.repaint();

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        rectAnimation = new RectAnimation();

    }

    public void keyTyped(KeyEvent e) {

    }

    public void keyPressed(KeyEvent e) {
        int id = e.getKeyCode();

        if (id == KeyEvent.VK_W) {
            w = true;
        } else if (id == KeyEvent.VK_S) {
            s = true;
        } else if (id == KeyEvent.VK_UP) {
            up = true;
        } else if (id == KeyEvent.VK_DOWN) {
            down = true;
        } else if (id == KeyEvent.VK_ESCAPE && gameStatus == 2) {
            gameStatus = 0;
        } else if (id == KeyEvent.VK_SHIFT && gameStatus == 0) {
            bot = true;
            start();
        }

        if (id == KeyEvent.VK_SPACE) {
            if (gameStatus == 0) {
                start();
                bot = false;
            } else if (gameStatus == 1) {
                gameStatus = 2;
            } else if (gameStatus == 2) {
                gameStatus = 1;
            }
        }
    }

    public void keyReleased(KeyEvent e) {

        int id = e.getKeyCode();

        if (id == KeyEvent.VK_W) {
            w = false;
        }
        if (id == KeyEvent.VK_S) {
            s = false;
        }
        if (id == KeyEvent.VK_UP) {
            up = false;
        }
        if (id == KeyEvent.VK_DOWN) {
            down = false;
        }

    }
}
